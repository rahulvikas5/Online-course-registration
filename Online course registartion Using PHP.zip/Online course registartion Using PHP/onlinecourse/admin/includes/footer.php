<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; <?php echo date('Y');?> Online Course Registration | By : <a href="http://www.phpgurukul.com/" target="_blank">PHPGURUKUL</a>
                </div>

            </div>
        </div>
    </footer>